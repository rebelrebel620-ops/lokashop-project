@extends('layout')
@section('title', $register ? 'Register' : 'Log in')
@section('body-class','logistics-login')
@section('content')
<div class="logistics-login-shell"><aside class="logistics-login-story"><span class="public-eyebrow">LOKASHOP LOGISTICS</span><h2>Moving every<br>order forward.</h2><p>Pick up. Sort. Deliver.<br>Keep local communities connected.</p></aside>
<div class="auth-wrap">
  <div class="auth-card">
    <img src="{{ asset('images/logistics-logo.png') }}" alt="LokaShop Logistics logo" width="64" height="64" style="width:64px;height:64px;object-fit:contain;border-radius:10px;flex-shrink:0;display:block">
    <h1>{{ $register ? 'Create your partner account' : 'Welcome back' }}</h1>
    <p class="switch">
      {{ $register ? 'Register as a rider or sorting center.' : 'Log in to manage pickups, parcels and deliveries.' }}
    </p>

    <form action="{{ $register ? '/register' : '/login' }}" method="post" enctype="multipart/form-data">
      @csrf
      @if($register)
        <label>Role</label>
        <select name="role">
          @foreach($roles as $role)
            <option value="{{ $role }}">{{ ucfirst(str_replace('_',' ',$role)) }}</option>
          @endforeach
        </select>

        <div class="field-grid">
          <div><label>Full name</label><input name="name" required value="{{ old('name') }}"></div>
          <div><label>Phone</label><input name="phone" required value="{{ old('phone') }}"></div>
        </div>

        <label>Business / center name (if applicable)</label>
        <input name="business_name">

        <label>Vehicle and plate (rider)</label>
        <input name="vehicle">

        <label>Identification document</label>
        <input type="file" name="id_document" required>

        <label>Permit / OR-CR (seller, center, rider)</label>
        <input type="file" name="permit_document">
      @endif

      <label for="partner-email">Email address</label>
      <input id="partner-email" type="email" autocomplete="email" placeholder="you@example.com" name="email" required value="{{ old('email') }}">

      <label for="partner-password">Password</label>
      <div class="partner-password"><input id="partner-password" type="password" name="password" autocomplete="current-password" required><button type="button" id="login-toggle" aria-label="Show password" aria-pressed="false">Show</button></div>

      @if($register)
        <label>Confirm password</label>
        <input type="password" name="password_confirmation" required>
      @endif

      <button class="block">{{ $register ? 'Submit for approval' : 'Log in' }}</button>
    </form>

    <p class="switch">
      @if($register)
        Already have an account? <a href="/login">Log in</a>
      @else
        Need a partner account? <a href="/register">Register here</a>
      @endif
    </p>
  </div>
</div>
</div>
<script>document.getElementById('login-toggle')?.addEventListener('click',function(){const input=document.getElementById('partner-password'),show=input.type==='password';input.type=show?'text':'password';this.textContent=show?'Hide':'Show';this.setAttribute('aria-pressed',String(show));this.setAttribute('aria-label',show?'Hide password':'Show password');});</script>
@endsection
