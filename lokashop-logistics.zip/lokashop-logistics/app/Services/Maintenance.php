<?php
namespace App\Services;
use Illuminate\Support\Facades\DB;
class Maintenance {
 public static function run():void {
  PickupRequests::refresh();
  DeliveryOffers::refresh();
  foreach(DB::table('promotions')->where('type','flash')->where('active',1)->where('reminder_sent',0)->where('starts_at','<=',now())->where('ends_at','>',now())->get() as $promo){DB::transaction(function()use($promo){$locked=DB::table('promotions')->where('id',$promo->id)->lockForUpdate()->first();if($locked->reminder_sent)return;$ids=DB::table('wishlists')->where('product_id',$promo->product_id)->pluck('buyer_id')->merge(DB::table('store_follows')->where('seller_id',$promo->seller_id)->pluck('buyer_id'))->unique()->all();Support::notify($ids,'Flash sale started for product #'.$promo->product_id);DB::table('promotions')->where('id',$promo->id)->update(['reminder_sent'=>1]);});}
  DB::table('users')->where('online',1)->where('last_seen_at','<=',now()->subMinutes(30))->update(['online'=>0]);
  foreach(DB::table('orders as o')->join('payments as p','p.order_id','=','o.id')->where('o.status','PLACED')->where('p.method','manual')->where('p.status','!=','paid')->where('o.created_at','<=',now()->subHour())->pluck('o.id') as $id)Commerce::cancel($id,'Unpaid order expired after one hour.');
  foreach(DB::table('orders')->where('status','DELIVERED')->where('delivered_at','<=',now()->subDays(7))->get() as $o){if(!DB::table('return_requests')->where('order_id',$o->id)->whereIn('status',['requested','approved','disputed'])->exists())Workflow::move(DB::table('parcels')->where('order_id',$o->id)->value('id'),'COMPLETED',$o->buyer_id,null,null,null,true);}
  foreach(DB::table('return_requests')->where('status','requested')->where('created_at','<=',now()->subDays(3))->get() as $x){DB::table('return_requests')->where('id',$x->id)->where('status','requested')->update(['status'=>'approved','response'=>'Automatically approved after 3 days.','responded_at'=>now(),'updated_at'=>now()]);Support::notify([$x->buyer_id,$x->seller_id],"Return #{$x->id} auto-approved.");}
  foreach(DB::table('assignments')->where('kind','!=','pickup')->where('status','offered')->where('expires_at','<=',now())->get() as $a)DB::table('assignments')->where('id',$a->id)->where('status','offered')->update(['status'=>'expired','updated_at'=>now()]);
  foreach(DB::table('parcels')->where('status','ASSIGNED_TO_RIDER')->get() as $p){$kind=$p->status==='READY_FOR_PICKUP'?'pickup':'delivery';if(DB::table('assignments')->where('parcel_id',$p->id)->where('kind',$kind)->whereIn('status',['offered','accepted','requested'])->exists())continue;$tried=DB::table('assignments')->where('parcel_id',$p->id)->where('kind',$kind)->whereIn('status',['declined','expired'])->count();if($tried>=3)continue;$company=DB::table('sorting_centers')->where('id',$p->center_id)->value('user_id');if($company){try{Dispatch::offer($p->id,$company,null,$kind);}catch(\Illuminate\Validation\ValidationException $e){/* Remain visible in the dispatch queue until capacity is available. */}}}
 }
}
